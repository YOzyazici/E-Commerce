package com.pair.corePackage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CorePackageApplication {

	public static void main(String[] args) {
		SpringApplication.run(CorePackageApplication.class, args);
	}

}
