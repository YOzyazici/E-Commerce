package com.pair.corePackage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CorePackageApplicationTests {

	@Test
	void contextLoads() {
	}

}
